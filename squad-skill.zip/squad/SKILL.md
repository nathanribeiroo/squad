---
name: squad
description: Talk to other agents and terminals connected to you on the Squad canvas, and read or write connected notes. Use when a message starts with [de: <Name> · pedido <id>], or when the user asks you to ask, tell, delegate to or check on another agent, or to read/update a note.
---

# Squad

You are running inside a Squad terminal. Squad is a canvas where agents and
shells are connected by wires; you can only talk to what is connected to you.
The `squad` command is on your PATH (if not, use "$SQUAD_CLI").

## Commands

- `squad list`: who you are and what is connected to you. Run it first and use names exactly as printed.
- `squad ask "Name" "message"`: send a message and wait for the reply. The reply is the other agent's final answer for that turn (or its screen when it has no hook). Set your shell tool timeout generously (minutes for real tasks).
- `squad ask "Name" --raw "keys"`: type keys into a terminal (escapes: \n Enter, \t Tab, \e ESC, \xNN byte, e.g. \x03 Ctrl-C) and get its screen back. Use for menus or shells.
- `squad ask --batch '{"A": "m1", "B": "m2"}'`: ask several at once; returns a JSON array of {name, output|error}.
- `squad check "Name"`: read a terminal's current screen without sending anything. Text still in someone's input box is not addressed to you.
- `squad reply <id> "message"`: answer request <id>.
- `squad note …`: read and write connected notes (`squad note help`).

For long messages use a heredoc: `squad ask "Name" <<'EOF'` … `EOF`.

## Receiving requests

A message that starts with `[de: Planejador · pedido 7f3a]` comes from the agent
Planejador, and Planejador is waiting for your answer. Do the work, then
either finish your turn with a clear final answer (Squad sends it back) or
run `squad reply 7f3a "…"`. If you need something from the sender while it
waits, `squad ask "Planejador" "…"` delivers your message as the answer.

## Rules

- If an ask times out, don't resend it: run `squad check "Name"` and wait again.
- Don't edit files another agent is changing right now.
- Conversations can be paused by the user, and chains are limited in depth;
  when a command says so, stop and tell the user.
