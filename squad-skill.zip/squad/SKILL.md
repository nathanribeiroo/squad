---
name: squad
description: Talk to other agents and terminals connected to you on the Squad canvas, read or write connected notes, use or open portals (a live browser page) and, as a manager, create your team of agents and floors (isolated copies of the repository). Use when a message starts with [de: <Name> · pedido <id>], when the user asks you to ask, tell, delegate to or check on another agent, to plan work for several agents, to read/update a note, or to look at, click or test something in the portal / browser.
---

# Squad

You are running inside a Squad terminal. Squad is a canvas where agents and
shells are connected by wires; you can only talk to what is connected to you.
The `squad` command is on your PATH (if not, use "$SQUAD_CLI").

If your session has the squad MCP tools (`mcp__squad__list`, `ask`, `note`,
`portal`, `new`…), prefer them: same commands with typed arguments, and most
need no approval. `keys`, `new_shell` and `portal_eval` can run commands, and
`floor_land` merges branches, so the user approves each call. The CLI below
works everywhere.

## Commands

- `squad list`: who you are and what is connected to you, with each agent's role (Planejador, Implementador, Revisor, Testador…). Run it first, use names exactly as printed, and give work to the agent whose role fits it. Your own role's instructions came with your session.
- `squad ask "Name" "message"`: send a message and wait for the reply. The reply is the other agent's final answer for that turn (or its screen when it has no hook). Set your shell tool timeout generously (minutes for real tasks).
- `squad ask "Name" --raw "keys"`: type keys into a terminal (escapes: \n Enter, \t Tab, \e ESC, \xNN byte, e.g. \x03 Ctrl-C) and get its screen back. Use for menus or shells.
- `squad ask --batch '{"A": "m1", "B": "m2"}'`: ask several at once; returns a JSON array of {name, output|error}.
- `squad check "Name"`: read a terminal's current screen without sending anything. Text still in someone's input box is not addressed to you.
- `squad reply <id> "message"`: answer request <id>.
- `squad note …`: read and write connected notes (`squad note help`).
- `squad portal …`: use a connected portal, a browser page the user also sees live on the canvas (`squad portal help`).
- `squad new`, `squad connect`, `squad close`: managers only, see below.
- `squad floor list`: the floors of the workspace; `create` and `land` are for managers, see below.

For long messages use a heredoc: `squad ask "Name" <<'EOF'` … `EOF`.

## Roles

`squad list` shows each agent's role; `squad roles` lists all of them with what
they do. The Arquiteto designs (a note "Arquitetura: …" with modules, contracts,
risks and parts that can run in parallel) and doesn't write product code. If
an architecture note is connected to you, read it before you implement or
review, and follow it; ask its author before departing from it.

## Notes

A note's name is unique in the workspace and permanent. When you create one
(`squad note create "Name"`), give it a clear name; don't create a second
note for the same thing, use `squad note list` to see the ones you have.
Names ignore case. The user may rename a note they made: its former names
keep working, and the reply tells you the current one; use that from then on.

## Portals

A portal is a real browser tab on the canvas; the user watches what you do
in it (your clicks show with your name). Typical loop:

1. `squad portal snapshot`: the page as a list like `@e3 button "Enviar" [x,y wxh]`.
2. Act on refs: `squad portal click @e3`, `squad portal fill @e2 "text"`, `squad portal key Enter`.
3. Snapshot again after anything that changes the page; refs expire then.

Also: `goto URL`, `back`, `reload`, `scroll down`, `screenshot` (prints
a PNG path you can open), `eval "js"` and `console` (errors and logs).
With several portals connected, name one first: `squad portal "Docs" snapshot`.
Use it to check your own work in the running app (dev server) after changes.

No portal connected? Open one: `squad portal create localhost:5173 "App"` creates it
next to you, connected to you (a few per agent). `squad portal close "App"`
removes one you created.

## Building a team (managers)

`squad list` says "You are a manager" when your terminal may create others
(the Planejador role does). Then:

1. Plan the work and decide who you need: one agent per independent task,
   with the role that fits (`squad roles` lists them: arch, impl, rev, test and the
   user's own). Call an Arquiteto (`--role arch`) when the change touches the
   structure (a new module, an API, a data format, a dependency) or will be
   split into parallel fronts; skip it for small, local tasks.
2. `squad new "Bia" --role impl` creates a terminal next to you, connected to
   you, with that role and your agent, and returns once it is ready.
   Options: `--agent codex|devin|gemini|claude|shell`, `--cwd folder`,
   `--command "npm run dev"` (with `--agent shell`, for a dev server).
3. Delegate with `squad ask` (`--batch` for parallel work) and check the results:
   have the Revisor review and the Testador test before telling the user it's done.
   The Arquiteto writes its design in a note ("Arquitetura: …"): connect that
   note to whoever implements and reviews, and use the parts it proposes to
   decide the floors.
4. `squad connect "A" "B"` wires two nodes (e.g. the Testador to a portal or
   the Implementador), `squad close "Name"` removes a terminal you created that
   is no longer needed. Leave the rest for the user to see.

Agents you create can't create others, and there is a limit per manager.
When one of them stops at a permission prompt (Claude Code's "Do you want to
proceed?", Devin's approval menu, Codex's approval request), don't answer it
for them with keys: tell the user, who sees that terminal on the canvas (on
its floor) and decides.

## Floors (managers)

A floor is an isolated copy of the repository: a git worktree on its own
branch, outside the project folder, with its own canvas. Use one per front
of work that would otherwise touch the same files at the same time.

1. `squad floor create "Login"` makes it from the last commit (uncommitted
   changes stay behind), on branch `login`, and runs the workspace's setup command.
2. `squad new "Bia" --role impl --floor "Login"` creates an agent on that floor,
   connected to you; it works in the floor's folder. Tell it to commit there.
3. When the floor's work is done and reviewed: `squad floor land "Login" --merge`
   merges its branch into the branch it started from (`--into main` for another),
   closes its terminals and removes its folder; the branch is kept. Without
   `--merge` nothing is merged. Landing is refused while the floor has uncommitted
   changes, and a merge with conflicts changes nothing: have an agent on the
   floor merge the base branch into the floor's branch, resolve, commit, and
   land again.

You can only land floors you created; the user can land or discard any floor.

## Receiving requests

A message that starts with `[de: Planejador · pedido 7f3a]` comes from the agent
Planejador, and Planejador is waiting for your answer. Do the work, then
either finish your turn with a clear final answer (Squad sends it back) or
run `squad reply 7f3a "…"`. If you need something from the sender while it
waits, `squad ask "Planejador" "…"` delivers your message as the answer.

## Rules

- If an ask times out, don't resend it: run `squad check "Name"` and wait again.
- Don't edit files another agent is changing right now.
- Conversations can be paused by the user, and chains are limited in depth;
  when a command says so, stop and tell the user.
