---
name: torre
description: Talk to other agents and terminals connected to you on the Torre canvas, read or write connected notes, use or open portals (a live browser page) and, as a manager, create your team of agents and floors (isolated copies of the repository). Use when a message starts with [de: <Name> · pedido <id>], when the user asks you to ask, tell, delegate to or check on another agent, to plan work for several agents, to read/update a note, or to look at, click or test something in the portal / browser.
---

# Torre

You are running inside a Torre terminal. Torre is a canvas where agents and
shells are connected by wires; you can only talk to what is connected to you.
The `torre` command is on your PATH (if not, use "$TORRE_CLI").

If your session has the torre MCP tools (`mcp__torre__list`, `ask`, `note`,
`portal`, `new`…), prefer them: same commands with typed arguments, and most
need no approval. `keys`, `new_shell` and `portal_eval` can run commands, and
`floor_land` merges branches, so the user approves each call. The CLI below
works everywhere.

## Commands

- `torre list`: who you are and what is connected to you, with each agent's role (Planejador, Especificador, Implementador, Revisor…). Run it first, use names (or the short callsigns, like IMP) exactly as printed, and give work to the agent whose role fits it. It also says who is busy (the request each one is answering, how many wait in its line) and who waits for whom: between two agents that fit, prefer the free one. Your own role's instructions came with your session.
- `torre ask "Name" "message"`: send a message and wait for the reply. The reply is the other agent's final answer for that turn (or its screen when it has no hook). An agent in the middle of a turn gets your message when that turn ends (requests to it go in one at a time). Set your shell tool timeout generously (minutes for real tasks).
- `torre ask "Name" --raw "keys"`: type keys into a terminal (escapes: \n Enter, \t Tab, \e ESC, \xNN byte, e.g. \x03 Ctrl-C) and get its screen back. Use for menus or shells.
- `torre ask --batch '{"A": "m1", "B": "m2"}'`: ask several at once; returns a JSON array of {name, output|error}.
- `torre check "Name"`: read a terminal's current screen without sending anything. Text still in someone's input box is not addressed to you.
- `torre wait "Name"`: wait for an agent's current turn to end and get its final answer, without sending anything (as with ask, set a generous shell tool timeout). Use it when an ask timed out while the agent was still working. If the agent isn't in a turn, you get its last answer at once. A message it sends you meanwhile ends the wait: answer with `torre reply`, then wait again.
- `torre reply <id> "message"`: answer request <id>.
- `torre note …`: read and write connected notes (`torre note help`).
- `torre portal …`: use a connected portal, a browser page the user also sees live on the canvas (`torre portal help`).
- `torre new`, `torre connect`, `torre close`: managers only, see below.
- `torre floor list`: the floors of the workspace and their checks; `create` and `land` are for managers, see below.
- `torre floor mark tests|review|security|design pass|fail "summary"`: on a floor, record the result of its tests, review, security review or design review on its latest commit, for the landing queue the user sees. A later commit makes the mark stale: mark again.

For long messages use a heredoc: `torre ask "Name" <<'EOF'` … `EOF`.

## Roles

`torre list` shows each agent's role; `torre roles` lists all of them, with what
they do and when to call each. Roles hand their work over in notes, by name:
"PRD: …" (Produto: the what and the why, with acceptance criteria), "Spec: …"
and "ADR-001: …" (Especificador: the how, and each decision), a stack
"Tarefas: …" with one note per task ("Tarefa 01: …"), "Design: …" (Designer),
"Arquitetura: …" (Arquiteto: the project's structure) and "Memória: …" (what
the whole team should know). Read the ones connected to you before you work
and follow them; ask their author before departing from one.
`torre note create "PRD: X" --template prd` starts a note with the sections of
such a document (templates: `torre note help`).

Before you say your work is done, run the project's checks (tests, build,
lint) and quote the command and its result; without that, say what is left.

## Notes

A note's name is unique in the workspace and permanent. When you create one
(`torre note create "Name"`), give it a clear name; don't create a second
note for the same thing, use `torre note list` to see the ones you have.
Names ignore case. The user may rename a note they made: its former names
keep working, and the reply tells you the current one; use that from then on.
Notes can be stacked: a wire to a stack reaches every note in it, and
`torre list` / `torre note list` show them with `stack: "Name"`. Read and
write each one by its own name. `torre note create "Tarefa 02: …" --stack "Tarefas: …"`
puts a new note on top of the stack of a note connected to you.

## Portals

A portal is a real browser tab on the canvas; the user watches what you do
in it (your clicks show with your name). Typical loop:

1. `torre portal snapshot`: the page as a list like `@e3 button "Enviar" [x,y wxh]`.
2. Act on refs: `torre portal click @e3`, `torre portal fill @e2 "text"`, `torre portal key Enter`.
3. Snapshot again after anything that changes the page; refs expire then.

Also: `goto URL`, `back`, `reload`, `scroll down`, `screenshot` (prints
a PNG path you can open), `eval "js"` and `console` (errors and logs).
With several portals connected, name one first: `torre portal "Docs" snapshot`.
Use it to check your own work in the running app (dev server) after changes.

No portal connected? Open one: `torre portal create localhost:5173 "App"` creates it
next to you, connected to you (a few per agent). `torre portal close "App"`
removes one you created.

## Building a team (managers)

`torre list` says "You are a manager" when your terminal may create others
(the Planejador role does). Then:

1. Plan the work in phases and call only who it needs: `torre roles` says when
   to call each role. A large feature: Produto (PRD), a Designer when there
   are new screens, then an Especificador (spec, ADRs and the task stack); an
   Arquiteto when the project's structure changes. A small change: straight
   to whoever implements it.
2. `torre new "Bia" --role impl` creates a terminal next to you, connected to
   you, with that role and your agent, and returns once it is ready.
   Options: `--agent codex|devin|gemini|claude|shell`, `--cwd folder`,
   `--command "npm run dev"` (with `--agent shell`, for a dev server).
3. Delegate with `torre ask` (`--batch` for parallel work) and check the results:
   don't take "done" without the checks' output and the diff, and have the
   Revisor review and the Testador test before telling the user it's done.
   Connect to you the notes the team delivers (`torre connect "PRD: …"`) and,
   to each agent, the ones it must read (`torre connect "Bia" "Spec: …"`).
   Follow the task stack's dependencies and suggested roles: tasks that
   don't depend on each other and touch different files can run on floors.
4. `torre connect "A" "B"` wires two nodes (e.g. the Testador to a portal or
   the Implementador). Leave the rest for the user to see.
5. There is a limit of terminals at a time: dismiss whoever finished their
   part and has nothing in the next phase. Have them hand over in the
   "Memória" note (what they did, decisions, what is pending), then
   `torre close "Name"`: the notes they created stay, connected to you. To call
   one back, create it again with the same name and role, connect its notes
   and the Memória, and say what it already did and what is needed now.

Agents you create can't create others, and there is a limit per manager.
When one of them stops at a permission prompt (Claude Code's "Do you want to
proceed?", Devin's approval menu, Codex's approval request), don't answer it
for them with keys: tell the user, who sees that terminal on the canvas (on
its floor) and decides.

## Floors (managers)

A floor is an isolated copy of the repository: a git worktree on its own
branch, outside the project folder, with its own canvas. Use one per front
of work that would otherwise touch the same files at the same time.

1. `torre floor create "Login"` makes it from the last commit (uncommitted
   changes stay behind), on branch `login`, and runs the workspace's setup command.
2. `torre new "Bia" --role impl --floor "Login"` creates an agent on that floor,
   connected to you; it works in the floor's folder. Tell it to commit there.
3. When the floor's work is done, its tester and reviewer mark it (and a
   Segurança or a Designer, if it has them: `torre floor mark`);
   `torre floor list` shows whether the marks passed on its latest commit.
   Then: `torre floor land "Login" --merge`
   merges its branch into the branch it started from (`--into main` for another),
   closes its terminals and removes its folder; the branch is kept. Without
   `--merge` nothing is merged. Landing is refused while the floor has uncommitted
   changes, and a merge with conflicts changes nothing: have an agent on the
   floor merge the base branch into the floor's branch, resolve, commit, and
   land again.

You can only land floors you created; the user can land or discard any floor.

## Receiving requests

A message that starts with `[de: Planejador · pedido 7f3a]` comes from the agent
Planejador, and Planejador is waiting for your answer. Do the work, then
either finish your turn with a clear final answer (Torre sends it back) or
run `torre reply 7f3a "…"`. If you need something from the sender while it
waits, `torre ask "Planejador" "…"` delivers your message as the answer.

## Rules

- If an ask times out while the agent is still in its turn, don't resend it: `torre wait "Name"` returns its answer when it finishes.
- If Torre restarted while you waited (a torre command failed to reach it, or
  you were told your work was interrupted), agents continue their
  conversations: use `torre wait "Name"` or `torre check` before resending a request.
- When you were asked something, your final answer is what goes back: don't
  end your turn with progress ("still waiting for X") while agents you called
  are working. Wait for them; stop early only when something needs the user
  (a question or a permission prompt on someone's screen), and say what.
- Don't edit files another agent is changing right now.
- Conversations can be paused by the user, and chains are limited in depth;
  when a command says so, stop and tell the user.
